# Pacote de prompts — dataset-eurlex

Conteúdo:

- `00_PROMPT_ATUALIZAR_ARQUITETURA.md` — prompt mestre para atualizar a arquitetura atual e instalar o fluxo operacional.
- `docs/CODEX_WORKFLOW.md` — regras para comandos `execute etapa N`, `próxima etapa` e `status`.
- `docs/RESEARCH_DESIGN.md` — desenho metodológico consolidado.
- `prompts/ETAPA_01_FONTE.md`
- `prompts/ETAPA_02_CORPUS.md`
- `prompts/ETAPA_03_METODOLOGIA.md`
- `prompts/ETAPA_04_BENCHMARK.md`
- `prompts/ETAPA_05_REFERENCE_LOCK.md`
- `prompts/ETAPA_06_G0_G1_G2.md`
- `prompts/ETAPA_07_COMPARACAO.md`
- `prompts/ETAPA_08_RELATORIO.md`

Ordem recomendada agora:

1. Entregar ao Codex o conteúdo de `00_PROMPT_ATUALIZAR_ARQUITETURA.md`.
2. Deixar o Codex atualizar o projeto sem executar nenhuma etapa.
3. Após a confirmação de que o projeto permanece em `setup`, usar apenas:
   - `execute etapa 1`
   - depois `próxima etapa`
4. O único gate substantivo esperado ocorre entre as etapas 4 e 5.
