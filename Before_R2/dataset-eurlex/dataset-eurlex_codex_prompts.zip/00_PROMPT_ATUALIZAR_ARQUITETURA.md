# PROMPT MESTRE — ATUALIZAR A ARQUITETURA E DEIXAR `dataset-eurlex` PRONTO PARA EXECUÇÃO POR ETAPAS

Você está no VS Code trabalhando no repositório principal `Prf-David`.

Já existe um núcleo inicial:

`Prf-David/dataset-eurlex/`

Ele já contém, no mínimo:

- `README.md`
- `AGENTS.md`
- `01_source/`
- `02_corpus/`
- `03_human/`
- `04_prompts/`
- `05_runs/`
- `06_comparison/`
- `07_report/`
- `config/`
- `logs/`

Sua tarefa agora é **atualizar a arquitetura operacional e o desenho completo da pesquisa**, sem iniciar nenhuma etapa empírica.

O resultado deve permitir que, depois desta atualização, o pesquisador controle todo o fluxo apenas com comandos curtos como:

- `execute etapa 1`
- `execute etapa 2`
- ...
- `execute etapa 8`
- `próxima etapa`
- `status`

## 1. Regra central

NÃO execute a Etapa 1.

NÃO consulte EUR-Lex.

NÃO selecione o ato.

NÃO execute modelos.

NÃO produza codificação.

Sua tarefa é apenas estrutural e documental.

## 2. Desenho de pesquisa a ser incorporado

O experimento é um **piloto metodológico exploratório de caso único**.

Parâmetros fixos:

- 1 ato normativo do EUR-Lex;
- foco preferencial em regulação climática;
- 1 corpus textual normalizado e bloqueado;
- 3 condições experimentais: G0, G1 e G2;
- 1 execução por condição;
- 3 execuções no total;
- referência construída como `benchmark de referência adjudicado pelo pesquisador`;
- papel humano substantivo reduzido a um único gate de adjudicação;
- comparação descritiva, não inferencial;
- nenhuma generalização estatística a partir do piloto.

### G0
Condição geral, sem codebook completo nem orientação substantiva especializada.

### G1
Condição com orientação metodológica e codebook.

### G2
Condição com tudo de G1 mais orientação substantiva pertinente ao domínio climático/regulatório.

## 3. Máquina de estados

Incorporar ao projeto:

```text
setup
  ↓
source_acquired
  ↓
corpus_locked
  ↓
methodology_locked
  ↓
awaiting_reference_adjudication
  ↓
reference_locked
  ↓
runs_complete
  ↓
analyzed
  ↓
completed
```

## 4. Novo diretório `prompts/`

Criar na raiz:

`dataset-eurlex/prompts/`

Copiar/instalar nele os oito prompts oficiais:

- `ETAPA_01_FONTE.md`
- `ETAPA_02_CORPUS.md`
- `ETAPA_03_METODOLOGIA.md`
- `ETAPA_04_BENCHMARK.md`
- `ETAPA_05_REFERENCE_LOCK.md`
- `ETAPA_06_G0_G1_G2.md`
- `ETAPA_07_COMPARACAO.md`
- `ETAPA_08_RELATORIO.md`

Não confundir esse diretório com `04_prompts/`.

A distinção é:

- `prompts/` = instruções operacionais do Codex para cada fase;
- `04_prompts/` = prompts experimentais G0/G1/G2, que só serão preenchidos na Etapa 6.

## 5. Novo diretório `docs/`

Criar:

`dataset-eurlex/docs/`

Adicionar:

- `docs/CODEX_WORKFLOW.md`
- `docs/RESEARCH_DESIGN.md`

### CODEX_WORKFLOW.md

Deve definir:

- comandos curtos;
- mapa das etapas;
- pré-condições;
- estados;
- regra de `próxima etapa`;
- regra de `status`;
- gate humano único;
- integridade experimental;
- comportamento diante de bloqueios.

### RESEARCH_DESIGN.md

Deve documentar:

- pergunta analítica;
- caso único;
- G0/G1/G2;
- benchmark adjudicado;
- papel humano mínimo;
- comparações;
- métricas descritivas;
- limitações;
- escalabilidade futura.

## 6. Atualização de `AGENTS.md`

Reescreva ou complemente `AGENTS.md` para incorporar o protocolo de orquestração.

O agente deve ser instruído a interpretar automaticamente:

### `execute etapa N`

Carregar o arquivo correto em `prompts/` e executar apenas aquela etapa.

### `próxima etapa`

Ler o status e executar a próxima etapa legal.

### `status`

Apenas informar o estado atual e próximo passo.

### Gate obrigatório

Se o projeto estiver em:

`awaiting_reference_adjudication`

não permitir avanço para a Etapa 5 enquanto `03_human/human_review.csv` não contiver a revisão do pesquisador.

Não criar outros gates humanos sem necessidade metodológica ou técnica objetiva.

## 7. Atualização de `README.md`

Atualizar o README principal para representar o novo fluxo simplificado:

```text
SETUP
  ↓
ETAPA 1 — fonte
  ↓
ETAPA 2 — corpus
  ↓
ETAPA 3 — metodologia
  ↓
ETAPA 4 — benchmark assistido
  ↓
HUMAN GATE ÚNICO
  ↓
ETAPA 5 — reference lock
  ↓
ETAPA 6 — G0 / G1 / G2
  ↓
ETAPA 7 — comparação
  ↓
ETAPA 8 — relatório
```

Deixar claro que:

- há apenas um ato;
- há apenas três execuções experimentais;
- o objetivo é piloto metodológico;
- o pesquisador deve poder operar o projeto por comandos curtos.

## 8. Atualização de `config/project.yaml`

Manter o status atual como:

`setup`

Adicionar ou confirmar campos equivalentes a:

```yaml
project:
  name: dataset-eurlex
  status: setup
  study_type: single_case_methodological_pilot

corpus:
  number_of_documents: 1
  source: EUR-Lex
  celex: null
  title: null
  url: null

human_role:
  mode: minimal_adjudication
  required_gate: HUMAN_GATE_REFERENCE_ADJUDICATION

reference:
  type: researcher_adjudicated_reference_benchmark
  locked: false
```

Não preencher CELEX.

## 9. Atualização de `config/experiment.yaml`

Configurar:

```yaml
experiment:
  status: not_started

design:
  documents: 1
  conditions: 3
  conditions_names:
    - G0
    - G1
    - G2
  runs_per_condition: 1
  total_expected_runs: 3

controls:
  same_document_for_all_conditions: true
  independent_model_runs: true
  benchmark_hidden_from_experimental_agents: true
  human_validation_mode: minimal_adjudication

model:
  provider: OpenAI
  model: null
  reasoning_effort: null

execution:
  automated: true
  api: null
```

Não escolher silenciosamente modelo, reasoning ou método de chamada.

Esses campos devem permanecer configuráveis até a Etapa 6.

## 10. Diretório `methodology/`

Criar vazio ou com README preparatório:

`dataset-eurlex/methodology/`

A Etapa 3 será responsável por criar:

- `codebook.md`
- `strings.yaml`
- `coding_schema.json`
- `methodology_manifest.yaml`

Não produzir esses arquivos substantivos agora.

## 11. Regras de integridade a incorporar

Registrar claramente:

1. o projeto é independente dos resultados empíricos anteriores;
2. material histórico pode ser usado como fonte metodológica, mas não como ground truth;
3. um único `act.md` será usado por todas as condições;
4. G0/G1/G2 nunca podem acessar o benchmark;
5. execuções experimentais devem ser independentes;
6. respostas brutas devem ser preservadas;
7. nenhum run deve ser repetido porque teve desempenho ruim;
8. retries só por falha técnica;
9. arquivos bloqueados não podem ser modificados silenciosamente;
10. logs devem registrar mudanças de estado.

## 12. Verificação automática da arquitetura

Após as alterações, faça uma verificação completa e confirme:

- os oito prompts operacionais existem;
- `docs/CODEX_WORKFLOW.md` existe;
- `docs/RESEARCH_DESIGN.md` existe;
- `AGENTS.md` reconhece comandos curtos;
- `README.md` mostra o fluxo atualizado;
- `project.status` continua `setup`;
- `experiment.status` continua `not_started`;
- nenhum ato foi selecionado;
- nenhum resultado foi produzido;
- G0/G1/G2 não foram executados;
- não houve importação de resultados empíricos anteriores.

## 13. Teste lógico sem execução

Faça apenas testes de roteamento, sem executar etapas.

Verifique que:

- `execute etapa 1` resolveria para `prompts/ETAPA_01_FONTE.md`;
- `execute etapa 4` resolveria para `prompts/ETAPA_04_BENCHMARK.md`;
- `próxima etapa`, com status `setup`, resolveria para a Etapa 1;
- `próxima etapa`, com status `awaiting_reference_adjudication`, bloquearia se a revisão humana não estiver concluída;
- `status` não alteraria nenhum arquivo substantivo.

Não execute os prompts durante esses testes.

## 14. Relatório final desta atualização

Criar:

`logs/architecture_update.md`

Registrar:

- arquivos criados;
- arquivos modificados;
- validações realizadas;
- eventuais problemas.

Ao final, apresentar ao pesquisador apenas:

1. estrutura atualizada;
2. confirmação de que o fluxo por comandos curtos está operacional;
3. confirmação de que o projeto continua em `setup`;
4. próximo comando disponível:

`execute etapa 1`

PARE.
