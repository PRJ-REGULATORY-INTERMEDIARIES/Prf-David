# Research package | 1 October 2026

Email + two **separate** technical notes:

- `00_Cover_Email_Draft.docx` and `.txt` — single cover message to David and Rotem, **not sent**.
- `01_David_Conceptual_Architecture_Technical_Note.docx` — manuscript-derived conceptual atlas and review boundaries.
- `02_Rotem_Coding_Calibration_Technical_Note.docx` — coding pilot, adjudication status and proposed alignment.

Website: https://prj-regulatory-intermediaries.github.io/ARQGOV_Model/

Source scope: David note is grounded in the provided 25-page manuscript. Rotem note draws on recorded project-level pilot status; original Rotem revised codebook was unavailable in this workspace for line-by-line verification.

The public repository contains preliminary manuscript-derived descriptions: check author permission for public sharing.
